import{p as t}from"../chunks/parse-page-metadata-Dau0YvEg.js";chrome.runtime.onMessage.addListener((e,a,r)=>{if(e.type==="SWEARCH_GET_PAGE_METADATA")return r(t(document,window.location.href)),!0});
